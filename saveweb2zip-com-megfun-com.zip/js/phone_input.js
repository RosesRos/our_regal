class PhoneInputService
{getStatus(){return true;}
init(input,options){let instance=this.getInstance(input);if(instance){instance.destroy();}
if(typeof options!=='object'){options={};}
options['separateDialCode']=true;options['autoInsertDialCode']=false;options['formatOnDisplay']=false;options['autoPlaceholder']='aggressive';options['utilsScript']='/assets/common/libraries/intl-tel-input/js/utils.js';options['dropdownContainer']=document.getElementById('phone-country-dropdown-container');window.intlTelInput(this.getHtmlElement(input),options);}
getNumber(input){return this.getInstance(input).getNumber();}
getInstance(input){return window.intlTelInputGlobals.getInstance(this.getHtmlElement(input));}
getHtmlElement(input){return typeof input==='object'?input:document.getElementById(input);}
setCountry(input,country){let instance=this.getInstance(input);if(instance){instance.setCountry(country);}}}
let PhoneInput=new PhoneInputService();